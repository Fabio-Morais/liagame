package lia.api;

public enum UnitType {
    WORKER, WARRIOR
}