package lia.api;

public enum MessageType {
    GAME_SETUP, GAME_STATE, RESPONSE
}