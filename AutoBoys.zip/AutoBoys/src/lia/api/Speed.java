package lia.api;

public enum Speed {
    NONE, FORWARD, BACKWARD
}
