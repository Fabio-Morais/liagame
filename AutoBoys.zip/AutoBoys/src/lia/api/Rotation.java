package lia.api;

public enum Rotation {
    NONE, LEFT, RIGHT, SLOW_LEFT, SLOW_RIGHT
}
