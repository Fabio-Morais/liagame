public class InitialAngle {
    public float angle;
    public float maxAngle;
    public float minAngle;

    public InitialAngle(float angle, float maxAngle, float minAngle) {
        this.angle = angle;
        this.maxAngle = maxAngle;
        this.minAngle = minAngle;
    }
}
