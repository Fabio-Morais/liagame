# Java Bot #

##### Build the project manually #####
* ``` gradlew build ```
* Check if it works: ``` java -jar build/libs/java-bot.jar ```

##### Use in IntelliJ IDEA #####

* Choose File->New->Project From Existing Sources
* Follow the instructions
* On the last screen check:
    * Use auto-import
    * Use gradle 'wrapper' task configuration